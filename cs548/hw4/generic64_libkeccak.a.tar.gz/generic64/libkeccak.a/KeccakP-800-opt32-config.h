#define KeccakP800_implementation_config "alternate flavor, all rounds unrolled"
#define KeccakP800_fullUnrolling
#define KeccakP800_useFlavorBis
